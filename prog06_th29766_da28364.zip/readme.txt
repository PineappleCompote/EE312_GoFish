The github repo for this project is 
https://github.com/PineappleCompote/EE312_GoFish.git


This program simulates two players in a classic game of go fish. All results from the game are recorded in gofish_results.txt!

use command ./test to run the program.